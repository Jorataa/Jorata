# JORATA website visual assets

Website appearance only. No game logic, game content, page structure, AI logic, or gameplay assets are included or changed.

## Start here
Open previews/asset_preview.html locally. It uses relative paths and requires no build tools, network, or installation. Copy assets into your existing public/assets/jorata directory and update existing image/CSS references only. Preview text and sample cards demonstrate appearance, not changes to the real site.

## Asset map
- backgrounds/hero_bg_main.png: 1536 × 1024 opaque city illustration. Use cover, positioned right/bottom; keep headings as live HTML over the dark left sky. Main image is a finished composite, not an isolated skyline.
- backgrounds/hero_bg_foreground.png: 2048 × 768 transparent independent rooftop layer; align bottom, pointer-events:none. These layers support subtle two-plane parallax, not a fully disassembled scene.
- overlays/hero_clouds.png: separate transparent cloud decoration. Use sparingly.
- backgrounds/section_bg_games.png and section_bg_notes.png: 1600 × 800 quiet reusable section surfaces. Footer: 1600 × 360.
- overlays/: transparent cyan glow, vignette, particles; pixel grid is a 96 × 96 repeat tile. Usually choose one overlay, not all of them.
- panels/: decorative raster skins and an independent hover border. Do not bake text into these.
- buttons/: eight primary/secondary state exports, chips, badge, tab, nav indicator. PNGs contain no labels; place accessible real text above them.
- icons/: 17 custom 24 × 24 SVGs. Inline them to inherit currentColor. With <img>, currentColor defaults to black; set via inline SVG or CSS mask for colored icons.
- assistant/: original simple robot SVG mark, widget frame, panel, bubble. This is an optional visual mark, not a replacement for an existing assistant character. Keep existing behavior and assets if already established.
- branding/: transparent wordmark PNG, editable SVG wordmark, emblem, favicon PNG and ICO. The SVG wordmark uses Arial/Helvetica/system sans; PNG is the fixed rendering.
- dividers/: subtle separator, streak, corner ornament, pixel sparkle.

## Responsive usage
Prefer website-assets.css for buttons and panel surfaces; it keeps corners crisp at any size. If using a PNG panel, use border-image with 36 source-pixel slices and a 1px transparent border, or overlay a proportionally scaled image. Do not stretch raster borders or place text inside the images. Typical button raster source is 400 × 104; intended at 200 × 52 CSS pixels. Panel source is generally at 2× display density. Use modern CSS geometry for touch targets and focus states.

The assistant belongs at the viewport bottom-right using position:fixed (see optional class), not an absolute coordinate inside a page section. On mobile respect safe areas and avoid covering content. Do not alter its interactions.

## Motion guidance
Optional parallax max 8–16px; clouds slow and subtle. No animation system is included. Honor prefers-reduced-motion and avoid continuous pulsing. Apply decoration with pointer-events:none and aria-hidden=true/empty alt.

## Palette
Background #080f1c · surface #101e30 · border #294254 · text #e9f3f7 · muted #a7bbc9 · accent #6be6df · warm #dbb178. Use dark #08202a text on cyan buttons. Accent is for priority; warm details should be rare.

## Production notes
Artwork was created with the built-in image generation tool; simple UI assets and SVG icons were drawn programmatically. Original generation prompts are included. PNG files are lossless optimized. Do not load all backgrounds together. SVG icons are editable. No website repository was supplied or modified; installation is still needed in your existing site.
